package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "user" or "assistant"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionExecuted: String? = null
)

@Entity(tableName = "intruder_logs")
data class IntruderLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val photoPath: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val triggerReason: String = "Wrong Unlock PIN"
)

enum class LicensePlan(val title: String, val features: List<String>) {
    FREE(
        "Free",
        listOf("Core Voice Commands", "Local Hindi/English Parser", "Basic App Launching")
    ),
    PRO(
        "Pro",
        listOf("Full WhatsApp Voice & Text Bot", "Anti-Theft Siren & Intruder Selfie", "Gesture & Phone Control", "Unlimited Gemini Live")
    ),
    LIFETIME(
        "Lifetime",
        listOf("All Pro Features Forever", "Screen OCR Bounding Box Taps", "Continuous Camera Vision", "VIP Priority Processing")
    )
}

data class LicenseStatus(
    val key: String = "",
    val plan: LicensePlan = LicensePlan.FREE,
    val deviceId: String = "",
    val expiryTimestamp: Long = 0L,
    val isValid: Boolean = true,
    val errorMessage: String? = null
)

data class PendingAction(
    val actionType: String, // "whatsapp_send", "phone_call", "siren_disarm"
    val description: String,
    val spokenPrompt: String,
    val recipient: String? = null,
    val messageText: String? = null,
    val contactName: String? = null,
    val phoneNumber: String? = null
)
