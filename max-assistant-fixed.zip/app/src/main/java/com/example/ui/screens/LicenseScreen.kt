package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MaxApplication
import com.example.data.model.LicensePlan
import com.example.data.model.LicenseStatus
import com.example.ui.theme.BrightCoral
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LicenseScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = context.applicationContext as MaxApplication

    var currentLicense by remember { mutableStateOf(app.securityManager.getCurrentLicenseStatus()) }
    var enteredKey by remember { mutableStateOf(app.securityManager.storedLicenseKey) }
    var keyValidationMessage by remember { mutableStateOf<String?>(null) }
    var isKeyValid by remember { mutableStateOf(currentLicense.isValid) }

    // Admin generator modal state
    var showAdminGenerator by remember { mutableStateOf(false) }
    var adminPassphraseInput by remember { mutableStateOf("") }
    var adminTargetDevice by remember { mutableStateOf(app.securityManager.deviceId) }
    var selectedPlanToGenerate by remember { mutableStateOf(LicensePlan.LIFETIME) }
    var generatedKeyOutput by remember { mutableStateOf<String?>(null) }
    var adminError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VpnKey, contentDescription = "License", tint = GoldenAmber, modifier = Modifier.size(26.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("LICENSE ACTIVATION", fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 16.sp)
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DarkSapphire,
                modifier = Modifier.clickable { showAdminGenerator = !showAdminGenerator }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin", tint = GoldenAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Admin Key Gen", color = GoldenAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Current Plan Badge Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, if (currentLicense.plan == LicensePlan.LIFETIME) GoldenAmber else NeonCyan, RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("CURRENT PLAN", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(
                            text = currentLicense.plan.title.uppercase(),
                            color = if (currentLicense.plan == LicensePlan.LIFETIME) GoldenAmber else NeonCyan,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Icon(
                        imageVector = if (currentLicense.plan == LicensePlan.LIFETIME) Icons.Default.Star else Icons.Default.Key,
                        contentDescription = "Badge",
                        tint = if (currentLicense.plan == LicensePlan.LIFETIME) GoldenAmber else NeonCyan,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Device ID: ${app.securityManager.deviceId}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                if (currentLicense.expiryTimestamp > 0L) {
                    val expFormatted = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(currentLicense.expiryTimestamp))
                    Text(
                        text = "Valid Until: $expFormatted",
                        color = EmeraldGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                } else if (currentLicense.plan == LicensePlan.LIFETIME) {
                    Text("Lifetime Unlimited Access", color = GoldenAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Included Features:", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                for (feature in currentLicense.plan.features) {
                    Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = "Yes", tint = EmeraldGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(feature, color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }

        // Enter License Key Box
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DeepSlate),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Activate License Key", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Validated 100% offline using hardware HMAC-SHA256 cryptographic verification.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                OutlinedTextField(
                    value = enteredKey,
                    onValueChange = { enteredKey = it },
                    label = { Text("Enter Key (e.g. MAX-PRO-...)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val status = app.securityManager.validateLicense(enteredKey)
                        if (status.isValid) {
                            app.securityManager.storedLicenseKey = enteredKey
                            currentLicense = status
                            isKeyValid = true
                            keyValidationMessage = "License successfully activated for ${status.plan.title} plan!"
                            app.ttsManager.speak("License activated successfully!")
                        } else {
                            isKeyValid = false
                            keyValidationMessage = status.errorMessage ?: "Invalid key."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Validate & Activate Key", color = CyberNavy, fontWeight = FontWeight.Bold)
                }

                keyValidationMessage?.let { msg ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isKeyValid) EmeraldGreen.copy(alpha = 0.2f) else BrightCoral.copy(alpha = 0.2f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (isKeyValid) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = "Status",
                                tint = if (isKeyValid) EmeraldGreen else BrightCoral,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(msg, color = if (isKeyValid) EmeraldGreen else BrightCoral, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Admin Key Generator Section
        AnimatedVisibility(visible = showAdminGenerator) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldenAmber.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Instant License Key Generator (Admin)", color = GoldenAmber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Enter secret passphrase (default: 'MAXADMIN2026') to generate HMAC-signed license keys for any Android device ID.", color = TextSecondary, fontSize = 11.sp)

                    OutlinedTextField(
                        value = adminPassphraseInput,
                        onValueChange = { adminPassphraseInput = it },
                        label = { Text("Admin Passphrase") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = GoldenAmber
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = adminTargetDevice,
                        onValueChange = { adminTargetDevice = it },
                        label = { Text("Target Device ID (Default: this phone)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = GoldenAmber
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Plan selection
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (p in listOf(LicensePlan.PRO, LicensePlan.LIFETIME)) {
                            val isSel = selectedPlanToGenerate == p
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) GoldenAmber else DeepSlate,
                                modifier = Modifier.clickable { selectedPlanToGenerate = p }
                            ) {
                                Text(
                                    text = p.title,
                                    color = if (isSel) CyberNavy else TextPrimary,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (adminPassphraseInput.trim() == app.securityManager.adminPassphrase) {
                                adminError = null
                                val key = app.securityManager.generateLicenseKey(adminTargetDevice, selectedPlanToGenerate, 365)
                                generatedKeyOutput = key
                                enteredKey = key
                            } else {
                                adminError = "Incorrect admin passphrase."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldenAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Generate Key Now", color = CyberNavy, fontWeight = FontWeight.Bold)
                    }

                    adminError?.let {
                        Text(it, color = BrightCoral, fontSize = 12.sp)
                    }

                    generatedKeyOutput?.let { key ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DeepSlate,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Generated License Key:", color = GoldenAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(key, color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            cm.setPrimaryClip(ClipData.newPlainText("Max License Key", key))
                                            Toast.makeText(context, "Key copied to clipboard", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSapphire),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = NeonCyan, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Copy", color = NeonCyan, fontSize = 12.sp)
                                    }

                                    Button(
                                        onClick = {
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, "Here is your Max Assistant license key:\n$key")
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share License Key"))
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSapphire),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Share", tint = GoldenAmber, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Share", color = GoldenAmber, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
