package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberNavy = Color(0xFF0B132B)
val DeepSlate = Color(0xFF1C2541)
val SlateCard = Color(0xFF263353)
val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF00B4D8)
val DarkSapphire = Color(0xFF0077B6)
val GoldenAmber = Color(0xFFFFB703)
val BrightCoral = Color(0xFFFF5252)
val EmeraldGreen = Color(0xFF00E676)
val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF94A3B8)
val SurfaceBorder = Color(0x3348CAE4)
